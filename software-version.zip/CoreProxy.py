CoreLibs = __import__("fr-Xabi08-CAPAlgorythmCore", globals(), locals(), ["utils","basicDBCtrl","tuteurs", "relations","feedback"],0)
