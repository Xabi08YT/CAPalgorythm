#ifndef Py_INTERPRETERIDOBJECT_H
#define Py_INTERPRETERIDOBJECT_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef Py_LIMITED_API
#  define Py_CPYTHON_INTERPRETERIDOBJECT_H
#  include  "cpython/interpreteridobject.h"
#  undef Py_CPYTHON_INTERPRETERIDOBJECT_H
#endif

#ifdef __cplusplus
}
#endif
#endif /* !Py_INTERPRETERIDOBJECT_H */
